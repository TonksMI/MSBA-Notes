# Metals News Sentiment — Starter Project

This repo shows **how** to (legally & robustly) collect news articles relevant to the **metals industry** (and adjacent sectors) and run sentiment analysis.

## Approach (high level)
1) **Ingest** using lowest-friction, policy-safe sources first:
   - **RSS/Atom** feeds (fast, TOS‑friendly).
   - **GDELT 2.1 API** for broad global coverage.
   - (Optional) **Direct crawl** of allowed domains via sitemaps/robots rules.

2) **Filter** with a domain taxonomy of metals & adjacent industries using keyword lists and simple NER to keep only relevant articles.

3) **Normalize & dedupe** (canonical URL, hash of text).

4) **Extract text** (trafilatura/readability) + clean (boilerplate removal, language detection).

5) **Sentiment**:
   - **Headline sentiment** with VADER (works well for short text).
   - **Body sentiment** with **FinBERT** (`ProsusAI/finbert`) for finance/econ tone.
   - Optional: **Entity/Aspect sentiment** (spaCy NER + sentence windows).

6) **Store** to SQLite/CSV and schedule via cron/Airflow.

## Quickstart
```bash
# 1) Create a venv (recommended)
python -m venv .venv && source .venv/bin/activate

# 2) Install deps (CPU ok)
pip install -r requirements.txt

# 3) (Optional) Install spaCy model for NER
python -m spacy download en_core_web_sm

# 4) Run with default sources & keywords
python main.py --hours 24 --out data/run_$(date +%F).csv

# 5) Inspect results
python explore.py data/run_$(date +%F).csv
```

> Note: The scripts respect `robots.txt` and throttle requests. Prefer **RSS** and **APIs** (GDELT) whenever possible; only crawl sites you’re allowed to.

## Files
- `main.py` — Orchestrates ingestion (RSS + GDELT + optional crawl), filtering, extraction, sentiment, and output.
- `explore.py` — Small EDA/summary of labeled sentiments.
- `keywords.yaml` — Domain taxonomy for metals & adjacent industries.
- `sources.yaml` — Known RSS feeds + site seeds (edit to your needs).
- `requirements.txt` — Python deps.
- `data/` — Outputs go here.

## Legal & Ethics
- Check each site's **TOS** and **robots.txt** before crawling.
- Use **APIs/RSS** first. Crawl only allowed paths, with delays, and a clear `User-Agent` string.
- Store **only** what's needed. Avoid PII. Honor takedown requests.
- Cache results; avoid hammering endpoints.
- For paid sites, use their **official APIs**.

## Notes
- FinBERT gives 3 labels (positive, neutral, negative). We map to a signed score for aggregation.
- For better domain accuracy, consider fine‑tuning a transformer on metals‑specific news (labeled samples).
- For country/market slant, record `source_country` and `language` for later stratified analysis.
